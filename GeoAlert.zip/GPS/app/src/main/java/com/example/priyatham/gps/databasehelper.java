package com.example.priyatham.gps;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.Cursor;
import android.widget.Toast;


/**
 * Created by lavankumar on 19-03-2017.
 */



public class databasehelper extends SQLiteOpenHelper {

    public static final String d_name="geoalert";
    public static final String t_name="location";
    public static final String col_1="ID";
    public static final String col_2="lattitude";
    public static final String col_3="longitude";
    public static final String col_4="mode";
    public databasehelper(Context context)
    {
        super(context,d_name,null,1);

    }
    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("create table location (ID integer primary key AUTOINCREMENT,lattitude  REal,longitude Real,mode text);" );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("drop table if  exists "+t_name);
        onCreate(db);
    }
    public boolean insertdata(double lat,double lon,String mode)
    {
        SQLiteDatabase  pdbase=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put(col_2,lat);
        cv.put(col_3,lon);
        cv.put(col_4,mode);
        long k=  pdbase.insert(t_name,null,cv);
        if(k==-1)
            return  true;
        return false;
    }
    public String getdata()
    {
        SQLiteDatabase  pdbase=this.getReadableDatabase();

        Cursor res=pdbase.rawQuery("select * from location",null);
        res.moveToFirst();
        String d="";
        while(res.isAfterLast() == false){
            d=d+res.getString(res.getColumnIndex(col_4))+"--";
            res.moveToNext();
        }

        return d;
    }


}
