package com.example.priyatham.gps;

/**
 * Created by priyatham on 29/10/2017.
 */
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

/**
 * Created by lavankumar on 19-03-2017.
 */

public class databasehelper2 extends SQLiteOpenHelper {

    public databasehelper2 (Context context)
    {
        super(context,"geoalertdb",null,1);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("create table details ( id integer primary key autoincrement,lat Real,lon Real,status integer)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("drop table if exists details");
        onCreate(db);
    }
    public boolean insertdata(double name,double pass,int k)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("lat",name);
        cv.put("lon",pass);
        cv.put("status",k);
        if(db.insert("details",null,cv)==-1)
            return true;

        return false;
    }
    public String getdata()
    {
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor res=db.rawQuery("select * from details",null);
        res.moveToFirst();
        String d="";
        while(res.isAfterLast()==false)
        {
            d=d+res.getString(res.getColumnIndex("lat"))+" "+res.getString(res.getColumnIndex("lon"))+" "+res.getString(res.getColumnIndex("status"))+"\n\n";
            res.moveToNext();
        }
        return d;
    }
    public ArrayList<ArrayList<Double>> getvalues()
    {
        SQLiteDatabase db=this.getReadableDatabase();
        ArrayList<ArrayList<Double>> outer = new ArrayList<ArrayList<Double>>();

        Cursor res=db.rawQuery("select * from details",null);
        res.moveToFirst();
        while(res.isAfterLast()==false)
        {
            System.out.println(" running ");
            ArrayList<Double> inner = new ArrayList<Double>();
          /*  inner.add(5.0);
            inner.add(5.0);
            inner.add(1.0);*/
            inner.add(Double.parseDouble(res.getString(res.getColumnIndex("lat"))));
            inner.add(Double.parseDouble(res.getString(res.getColumnIndex("lon"))));
            inner.add(Double.parseDouble(res.getString(res.getColumnIndex("status"))));
            //inner.add(res.getDouble(res.getColumnIndex("lot")));
            //inner.add(1.0);
            // inner.add(res.getDouble(res.getColumnIndex("status")));
            res.moveToNext();
            outer.add(inner);
        }
        return outer;


    }
}

