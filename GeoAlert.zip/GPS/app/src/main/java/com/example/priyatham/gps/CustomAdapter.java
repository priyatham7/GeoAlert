package com.example.priyatham.gps;

/**
 * Created by priyatham on 29/10/2017.
 */


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;

import java.util.ArrayList;

/**
 * Created by lavankumar on 23-03-2017.
 */

public class CustomAdapter extends BaseAdapter {

    Context con;
    ArrayList<place> places;
    EditText name,notification,mode;
    LayoutInflater layoutInflater;
    public CustomAdapter(Context con, ArrayList<place> data) {

        this.con=con;
        this.places=data;
        layoutInflater = LayoutInflater.from(con);
    }

    @Override
    public int getCount() {
        return places.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View v, ViewGroup parent) {

        v=layoutInflater.inflate(R.layout.list_item_layout,null);
        name=(EditText) v.findViewById(R.id.name);
        notification=(EditText) v.findViewById(R.id.notification);
        mode=(EditText) v.findViewById(R.id.mode);
        name.setText(places.get(position).name);
        notification.setText(places.get(position).notification);
        mode.setText(places.get(position).mode);
        return v;
    }
}
