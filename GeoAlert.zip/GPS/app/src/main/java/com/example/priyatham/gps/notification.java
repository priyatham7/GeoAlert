package com.example.priyatham.gps;

/**
 * Created by priyatham on 29/10/2017.
 */


import android.app.Activity;
import android.os.Bundle;

/**
 * Created by lavankumar on 20-03-2017.
 */

public class notification extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notification_layout);
    }

}
