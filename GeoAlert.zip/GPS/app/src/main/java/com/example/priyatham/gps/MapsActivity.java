package com.example.priyatham.gps;

import android.support.v4.app.FragmentActivity;
import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import android.Manifest;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.location.Address;
import android.location.Geocoder;
import android.media.AudioManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static android.R.attr.data;
import static android.R.attr.itemBackground;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    databasehelper2 dbh;
    SeekBar sb;
    RadioGroup gr;
    EditText message,lname,title;
    int selected;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        dbh=new databasehelper2(this);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
        // Add a marker in Sydney and move the camera
        LatLng sydney = new LatLng(-34, 151);
        mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        mMap.setMyLocationEnabled(true);
        mMap.setOnMapLongClickListener(new GoogleMap.OnMapLongClickListener() {
            @Override
            public void onMapLongClick(final LatLng latLng) {
                mMap.addMarker(new MarkerOptions().position(latLng).title("this "));
                CharSequence modes[] = new CharSequence[] {"silent", "vibrate", "notify"};
              //  Toast toast = Toast.makeText(getBaseContext(), "long click", Toast.LENGTH_SHORT);
             //   toast.show();
                getdialog(latLng);

    /*   AlertDialog.Builder builder = new AlertDialog.Builder(MapsActivity.this);
        builder.setNegativeButton("Cancel",new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialog,int which)
            {
                Toast.makeText(getApplicationContext(), "You clicked on Cancel", Toast.LENGTH_SHORT).show();
            }
        });



                builder.setTitle("Pick a mode");
                int k;
                 final int selected = 0; // or whatever you want
                builder.setCancelable(true);
                builder.setSingleChoiceItems(modes, 1, null).setPositiveButton("save", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                int selectedPosition = ((AlertDialog)dialog).getListView().getCheckedItemPosition();
                                String details = null;
                                if( dbh.insertdata( latLng.latitude,latLng.longitude,selectedPosition))
                                    Toast.makeText(getApplicationContext(), "row not  added ", Toast.LENGTH_LONG).show();;
                                String d=dbh.getdata();
                                Toast.makeText(getApplicationContext(), d, Toast.LENGTH_LONG).show();
                                dialog.dismiss();
                                shownotification();
                                // Do something useful withe the position of the selected radio button
                            }
                        })
                        .show();*/


            }
        });

        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng point) {

                //  startService(new Intent(this,Myservice.class));
                Geocoder geo;
                List<Address> addresses = null;
                geo=new Geocoder(getBaseContext());
                try {
                    addresses = geo.getFromLocation(point.latitude, point.longitude, 1);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                MarkerOptions marker;
                if (addresses.size() > 0) {


                    marker = new MarkerOptions()
                            .position(new LatLng(point.latitude, point.longitude))
                            .title(addresses.get(0).getLocality());}
                else
                {
                    marker = new MarkerOptions()
                            .position(new LatLng(point.latitude, point.longitude))
                            .title("X");
                }
                mMap.addMarker(marker);
              //  System.out.println(point.latitude + "---" + point.longitude);


            }
        });
    }
    public void ss(View v)
    {
      //  Toast.makeText(this,"service pressed ",Toast.LENGTH_LONG).show();
        startService(new Intent(this,Myservice.class));
    }
    public void onSearch(View view) throws IOException {
        EditText tfadr=(EditText) findViewById(R.id.search);
        String location=tfadr.getText().toString();
        Geocoder geocoder=new Geocoder(this);
        List<Address> addresslist;
      //  Toast toast = Toast.makeText(this, location, Toast.LENGTH_SHORT);
       // toast.show();
        if(location!=null)
        {
          //  Toast.makeText(this, " entered if ", Toast.LENGTH_SHORT);
            //toast.show();
            addresslist=geocoder.getFromLocationName(location,1);
            Address address=addresslist.get(0);
            LatLng latlng=new LatLng(address.getLatitude(),address.getLongitude());
            mMap.addMarker(new MarkerOptions().position(latlng).title("U"));
            mMap.animateCamera(CameraUpdateFactory.newLatLng(latlng));
        }
        else
        {
          //  Toast.makeText(this, " not entered if ", Toast.LENGTH_SHORT);
            //toast.show();

        }

    }
    public void getdialog(final LatLng latLng)
    {

        View mdb= LayoutInflater.from(this).inflate(R.layout.my_dialog_box,null);
        (title) =(EditText)  mdb.findViewById(R.id.title);
        title.setKeyListener(null);

        message= (EditText) mdb.findViewById(R.id.message);
        lname= (EditText) mdb.findViewById(R.id.lname);
        gr= (RadioGroup) mdb.findViewById(R.id.radioGroup);
        sb= (SeekBar) mdb.findViewById(R.id.seekBar);
        sb.setEnabled(true);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
              //  Toast.makeText(MapsActivity.this,sb.getProgress()+" / "+sb.getMax(),Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        gr.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged (RadioGroup group,int checkedId){

                Log.d("chk", "id" + checkedId);

                if (checkedId == R.id.radioButton) {
                    selected=1;

                } else if (checkedId == R.id.radioButton2) {
                    selected=2;
                }
                else
                {
                    selected=3;
                }
            }
        });
        AlertDialog.Builder adb=new AlertDialog.Builder(this);
        adb.setView(mdb);
        adb.setCancelable(false);
        adb.setNegativeButton("Cancel",new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialog,int which)
            {
              //  Toast.makeText(getApplicationContext(), "You clicked on Cancel", Toast.LENGTH_SHORT).show();
            }
        });

        adb.setPositiveButton("save", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {

              //  Toast.makeText(getApplicationContext(),""+selected,Toast.LENGTH_LONG).show();
                String details = null;
                if( dbh.insertdata( latLng.latitude,latLng.longitude,selected))
                    Toast.makeText(getApplicationContext(), "row not  added ", Toast.LENGTH_LONG).show();
                //String d=dbh.getdata();
              //  Toast.makeText(getApplicationContext(), d, Toast.LENGTH_LONG).show();
                dialog.dismiss();
            }
        });
        adb.show();

    }
    public void shownotification()
    {
        NotificationCompat.Builder builder=new NotificationCompat.Builder(this);
        builder.setTicker("ticker");
        builder.setContentTitle("content title");
        builder.setSmallIcon(R.drawable.fiat);
        Intent intent=new Intent(this,notification.class);
        TaskStackBuilder tsb=TaskStackBuilder.create(this);
        tsb.addParentStack(notification.class);
        tsb.addNextIntent(intent);
        PendingIntent pin=tsb.getPendingIntent(0,PendingIntent.FLAG_UPDATE_CURRENT);
        builder.setContentIntent(pin);
        NotificationManager nm= (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.notify(0,builder.build());

    }
    public void balerts(View v)
    {
     //   Toast.makeText(this,"hi what is this ",Toast.LENGTH_LONG).show();
        Intent i=new Intent(MapsActivity.this,data.class);
        startActivity(i);
    }

}
