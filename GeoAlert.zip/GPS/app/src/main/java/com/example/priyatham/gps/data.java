package com.example.priyatham.gps;

/**
 * Created by priyatham on 29/10/2017.
 */

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.SupportMapFragment;

import java.util.ArrayList;

/**
 * Created by lavankumar on 23-03-2017.
 */

public class data extends Activity {

    ArrayList<String> ar;
    ArrayAdapter<String> ad;
    ArrayList<place> places;
    CustomAdapter ca;
    ListView lv,lview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data_layout);
        Toast.makeText(this,"in data ",Toast.LENGTH_LONG);
        lv=(ListView) findViewById(R.id.lview);
        places=new ArrayList<place>();
        places.add(new place("college1","silent","its college"));
        places.add(new place("college2","silent","its college"));
        places.add(new place("college3","silent","its college"));
        ca=new CustomAdapter(this,places);
        lv.setAdapter(ca);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(data.this,"pressed = "+position,Toast.LENGTH_LONG);
            }
        });
        //   View v=View.inflate(this,R.layout.list_item_layout,null);

     /*   lview=(ListView) findViewById(R.id.lview);
        ar=new ArrayList<String>();
        ad=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,ar);

        lview.setAdapter(ad);*/

    }
    public void add(View v)
    {
        Toast.makeText(this,"pressed ",Toast.LENGTH_LONG);

        //  ar.add("hi");
        //ad.notifyDataSetChanged();
        places.add(new place("hey","hey","hey"));
        ca.notifyDataSetChanged();

    }


}
