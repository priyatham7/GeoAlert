package com.example.priyatham.gps;

/**
 * Created by priyatham on 29/10/2017.
 */


import com.google.android.gms.maps.model.LatLng;

/**
 * Created by lavankumar on 23-03-2017.
 */

public class place {
    String mode;
    String name;
    String notification;
    LatLng latlng;

    public place( String name, String mode,String notification) {
        this.mode = mode;
        this.name = name;
        this.notification = notification;
        this.latlng = latlng;
    }
}

