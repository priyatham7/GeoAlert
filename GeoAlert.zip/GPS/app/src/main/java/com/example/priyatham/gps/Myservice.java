package com.example.priyatham.gps;

/**
 * Created by priyatham on 29/10/2017.
 */

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;

import android.location.LocationManager;
import android.media.AudioManager;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.NotificationCompat;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by lavankumar on 20-03-2017.
 */

public class Myservice extends Service implements LocationListener {
    private static final long MINIMUM_DISTANCE_CHANGE_FOR_UPDATES = 0; // in Meters
    private static final long MINIMUM_TIME_BETWEEN_UPDATES = 10; // in Milliseconds
    LocationManager lm;
    databasehelper2 db;

    @Override
    public void onCreate() {
        Toast.makeText(this, "Service Created", Toast.LENGTH_LONG).show();
        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        db=new databasehelper2(this);
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }


    @Override
    public void onStart(Intent intent, int startid) {
        Toast.makeText(this, "Service started", Toast.LENGTH_LONG).show();

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        lm.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                MINIMUM_TIME_BETWEEN_UPDATES,
                MINIMUM_DISTANCE_CHANGE_FOR_UPDATES,
                this
        );

    }

    @Override
    public void onDestroy() {
//        Toast.makeText(this, "Service stopped", Toast.LENGTH_LONG).show();

    }

    @Override
    public void onLocationChanged(Location location) {

        String message = String.format(
                "New Location \n Longitude: %1$s \n Latitude: %2$s",
                location.getLongitude(), location.getLatitude()
        );
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        checkdatabase(location);

    }

    public void checkdatabase(Location location1) {
     //   Toast.makeText(this,"check database ",Toast.LENGTH_LONG).show();
       // Toast.makeText(this,db.getdata(),Toast.LENGTH_LONG).show();

        ArrayList<ArrayList<Double>> outer = db.getvalues();
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        AudioManager am= (AudioManager) getSystemService(AUDIO_SERVICE);
        Integer a[]=new Integer[3];
        a[0]=AudioManager.RINGER_MODE_SILENT;
        a[1]=AudioManager.RINGER_MODE_VIBRATE;
        a[2]=AudioManager.RINGER_MODE_NORMAL;
        for (int i = 0; i < outer.size(); i++) {
          //  Toast.makeText(this," "+i,Toast.LENGTH_LONG).show();
            Location location2=new Location("");

            location2.setLatitude(outer.get(i).get(0));//your coords of course
            location2.setLongitude(outer.get(i).get(1));
         //   System.out.println(outer.get(i).get(0)+"  "+outer.get(i).get(1));
            if(location1.distanceTo(location2)<200)
            {
                am.setRingerMode(a[outer.get(i).get(2).intValue()]);
                notify("notifying...");
              //  Toast.makeText(this,"mode changed ",Toast.LENGTH_LONG).show();
            }
        }


    }
    @SuppressLint("WrongConstant")
    public void notify(String s) {
        Intent intent = new Intent();

        PendingIntent pIntent = PendingIntent.getActivity(this, 0, intent,
                0);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(getApplicationContext())
                .setTicker("Ticker Title").setContentTitle("Content Title")
                .setContentText(s)
                .setSmallIcon(R.drawable.ic_launcher_background)
                .setContentIntent(pIntent);
        Uri notificationSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        builder.setSound(notificationSound);
        Notification noti = builder.build();
        noti.flags = Notification.FLAG_AUTO_CANCEL;
        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        notificationManager.notify(0, noti);
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
     /*   Toast.makeText(this, "Provider status changed",
                Toast.LENGTH_LONG).show();*/

    }

    @Override
    public void onProviderEnabled(String provider) {
      /*  Toast.makeText(this, "Provider status enabled",
                Toast.LENGTH_LONG).show();*/

    }

    @Override
    public void onProviderDisabled(String provider) {
     /*   Toast.makeText(this,
                "Provider disabled by the user. GPS turned off",
                Toast.LENGTH_LONG).show();*/

    }


}
/*
public class MyLocationListener implements LocationListener {

    public void onLocationChanged(Location location) {
        String message = String.format(
                "New Location \n Longitude: %1$s \n Latitude: %2$s",
                location.getLongitude(), location.getLatitude()
        );
        Toast.makeText(Context.getBaseContext(), message, Toast.LENGTH_LONG).show();
    }

    public void onStatusChanged(String s, int i, Bundle b) {
        Toast.makeText(this, "Provider status changed",
                Toast.LENGTH_LONG).show();
    }

    public void onProviderDisabled(String s) {
        Toast.makeText(LbsGeocodingActivity.this,
                "Provider disabled by the user. GPS turned off",
                Toast.LENGTH_LONG).show();
    }

    public void onProviderEnabled(String s) {
        Toast.makeText(LbsGeocodingActivity.this,
                "Provider enabled by the user. GPS turned on",
                Toast.LENGTH_LONG).show();
    }

}*/
